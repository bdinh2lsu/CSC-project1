package prog01_aOrderedList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
* < Main class for managing an ordered list of Car objects. It reads car data from an input file, 
 * performs add or delete operations based on the file contents, and outputs the final list to an output file. 
 * The class utilizes custom scanner and printwriter methods for file operations.>
*
* CSC 1351 Programming Project No <1>
7
* Section <2>
*
* @author <Brandon Dinh>
* @since <3/17/24>
*
*/
public class Prog01_aOrderedList {
	  /**
	    * <The main method serves as the entry point for the program. It initializes the process by reading 
	    * an input file specified by the user, processes each line to either add or delete Car objects in 
	    * an aOrderedList, and outputs the final state of the list to a specified output file.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    public static void main(String[] args) {
        try {
            Scanner inputFileScanner = getInputFile("Enter input filename: ");
            aOrderedList<Car> orderedList = new aOrderedList<>();

            while(inputFileScanner.hasNextLine()) {
            	String input = inputFileScanner.nextLine();
            	String[] organize = input.split(",");
            	if(organize.length == 4 && organize[0].equals("A")) {
            		String make = organize[1];
            		int year = Integer.parseInt(organize[2]);
            		int price = Integer.parseInt(organize[3]);
            		orderedList.add(new Car(make, year, price));
            	} else if (organize[0].equals("D")) {
            		String dataMake = organize[1];
            		int dataYear = Integer.parseInt(organize[2]);
            		for(int i = 0; i < orderedList.size(); i++)
            			if(dataMake.equals(((Car)orderedList.get(i)).getMake()) && dataYear == (((Car)orderedList.get(i)).getYear())){
            				orderedList.remove(i);
            			}
            	}
            }		
              
            inputFileScanner.close();

            PrintWriter outputFile = getOutputFile("Enter output filename: ");
            outputFile.println("Number of cars: " + orderedList.size());
            for (int i = 0; i < orderedList.size(); i++) {
                Car car = orderedList.get(i);
                outputFile.printf("Make: %s\nYear: %d\nPrice: $%,d\n\n", car.getMake(), car.getYear(), car.getPrice());
            }
            outputFile.close();
        } catch (FileNotFoundException e) {
            System.out.println("File operation error: " + e.getMessage());
        }
    }
    /**
	    * < Prompts the user for the name of an input file and attempts to open it. If the file does not exist, 
	    * the user is prompted again until a valid file name is provided or the user chooses to cancel the operation.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
    	Scanner consoleScanner = new Scanner(System.in);
        System.out.println(userPrompt);
        String filename = consoleScanner.nextLine();
        File file = new File(filename);
        while (!file.exists()) {
            System.out.println("File specified <" + filename + "> does not exist. Would you like to continue? <Y/N>");
            String answer = consoleScanner.nextLine();
            if (answer.equalsIgnoreCase("N")) {
                throw new FileNotFoundException("User cancelled the operation.");
            }
            System.out.println("Enter input filename: ");
            filename = consoleScanner.nextLine();
            file = new File(filename);
        }
        return new Scanner(file);
    }
    /**
	    * < Prompts the user for the name of an output file and prepares it for writing. This method simplifies 
	    * the process of creating a PrintWriter object for file output, encapsulating the file creation.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
    	Scanner consoleScanner = new Scanner(System.in);
        System.out.println(userPrompt);
        String filename = consoleScanner.nextLine();
        return new PrintWriter(filename);
}
}