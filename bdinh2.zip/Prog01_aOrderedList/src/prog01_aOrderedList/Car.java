package prog01_aOrderedList;
/**
* <Represents a car with properties for make, year, and price. This class provides functionality to
* create car objects, compare them based on make and year, and generate a string representation
* for display purposes. It implements the Comparable interface to allow for sorting and comparison
* operations based on the make and year of the cars.>
*
* CSC 1351 Programming Project No <1>
* Section <2>
*
* @author <Brandon Dinh>
* @since <3/17/24>
*
*/
public class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;
    /**
	    * < Constructs a new Car instance with the specified make, year, and price.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
   
    public String getMake() {
        return make;
        //returns make of car.
    }
 int getYear() {
        return year;
    }
  //returns car production year.
    public int getPrice() {
        return price;
    }
  //returns price of car
    
    /**
	    * < Compares this car with another car for ordering. Cars are primarily compared by make, and
	    * secondarily by year if the makes are the same.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    @Override
    public int compareTo(Car other) {
        if (!this.make.equals(other.make)) {
            return this.make.compareTo(other.make);
        } else if (this.year != other.year) {
            return this.year - other.year;
        } else {
            return 0;
        }
    }
    /**
	    * < Returns a string of a car, including its make, year, and price.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    @Override
    public String toString() {
        return "Make: " + make + " Year: " + year + " Price: " + price + ";";
    }
}