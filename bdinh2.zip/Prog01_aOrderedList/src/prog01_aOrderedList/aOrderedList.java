package prog01_aOrderedList;
	import java.util.Arrays;
	import java.util.NoSuchElementException;
	/**
	* <A generic, ordered list implementation that stores elements in a sorted manner according to their
	* natural ordering. The class supports adding, removing, and accessing elements while maintaining
	* the order. It is capable of dynamically resizing to accommodate new elements. Additionally, this
	* class provides iterator functionalities to sequentially access elements in the list.>
	*
	* CSC 1351 Programming Project No <1>
	7
	* Section <2>
	*
	* @author <Brandon Dinh>
	* @since <3/17/24>
	*
	*/
	public class aOrderedList<T extends Comparable<T>> {
	    private Object[] oList;
	    private int numObjects = 0;
	    private static final int SIZEINCREMENTS = 20;
	    private int curr = 0;

	    /**
	    * <Method description>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */

	    public aOrderedList() {
	        oList = new Object[SIZEINCREMENTS];
	    }
	    /**
		    * <Adds an element to the ordered list in its correct position to maintain the sorted order.
		    * The list is automatically resized if its current capacity is exceeded.>
		    *
		    * CSC 1351 Programming Project No <1>
		    * Section <2>
		    *
		    * @author <Brandon Dinh>
		    * @since <3/17/24>
		    *
		    */
	    public void add(T newObject) {
	        if (numObjects == oList.length) {
	            oList = Arrays.copyOf(oList, oList.length + SIZEINCREMENTS);
	        }
	        int i;
	        for (i = 0; i < numObjects; i++) {
	            if (((T)oList[i]).compareTo(newObject) > 0) {
	                break;
	            }
	        }
	        System.arraycopy(oList, i, oList, i + 1, numObjects - i);
	        oList[i] = newObject;
	        numObjects++;
	    }
	    /**
		    * <Returns a string representation of the elements in the list, in sorted order, enclosed in brackets
		    * and separated by commas.>
		    *
		    * CSC 1351 Programming Project No <1>
		    * Section <2>
		    *
		    * @author <Brandon Dinh>
		    * @since <3/17/24>
		    *
		    */
	    @Override
	    public String toString() {
	        StringBuilder sb = new StringBuilder("[");
	        for (int i = 0; i < numObjects; i++) {
	            sb.append(oList[i].toString());
	            if (i < numObjects - 1) {
	                sb.append(", ");
	            }
	        }
	        sb.append("]");
	        return sb.toString();
	    }
	   
    public int size() {
        return numObjects;
    }
//Returns the number of elements currently stored in the list.
    
    public boolean isEmpty() {
        return numObjects == 0;
    }
    // Checks if the list is empty
    
    /**
	    * <Retrieves the element at the specified index in the list>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    // Retrieves the item at the specified index
    public T get(int index) {
        if (index >= 0 && index < numObjects) {
            return (T) oList[index];
        }
        throw new IndexOutOfBoundsException("Invalid index: " + index);
    }
    
    /**
	    * <Removes the item at the specified index>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
 
    public void remove(int index) {
        if (index >= 0 && index < numObjects) {
            for (int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            oList[numObjects - 1] = null;
            numObjects--;
        } else {
            throw new IndexOutOfBoundsException("Invalid index: " + index);
        }
    }
   
    public void reset() {
        curr = 0;
    }
    // Resets the iterator to the beginning of the list, allowing for a new iteration over the elements.
    
    /**
	    * <Returns the next element in the iteration, advancing the iterator by one position.>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more elements in the list");
        }
        return (T) oList[curr++];
    }
    
    public boolean hasNext() {
        return curr < numObjects;
    }
 // Check if there are more elements to iterate over
    
    /**
	    * <Remove the last element returned by the next method>
	    *
	    * CSC 1351 Programming Project No <1>
	    * Section <2>
	    *
	    * @author <Brandon Dinh>
	    * @since <3/17/24>
	    *
	    */
    public void remove() {
        if (curr <= 0) {
            throw new IllegalStateException("next() has not been called, or remove() has already been called after the last call to next()");
        }
        remove(curr - 1); 
        curr--;
    }
}
    
