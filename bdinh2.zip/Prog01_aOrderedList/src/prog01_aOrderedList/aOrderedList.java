package prog01_aOrderedList;
	import java.util.Arrays;
	import java.util.NoSuchElementException;
	public class aOrderedList<T extends Comparable<T>> {
	    private Object[] oList;
	    private int numObjects = 0;
	    private static final int SIZEINCREMENTS = 20;
	    private int curr = 0;

	    public aOrderedList() {
	        oList = new Object[SIZEINCREMENTS];
	    }

	    public void add(T newObject) {
	        if (numObjects == oList.length) {
	            oList = Arrays.copyOf(oList, oList.length + SIZEINCREMENTS);
	        }
	        int i;
	        for (i = 0; i < numObjects; i++) {
	            if (((T)oList[i]).compareTo(newObject) > 0) {
	                break;
	            }
	        }
	        System.arraycopy(oList, i, oList, i + 1, numObjects - i);
	        oList[i] = newObject;
	        numObjects++;
	    }

	    @Override
	    public String toString() {
	        StringBuilder sb = new StringBuilder("[");
	        for (int i = 0; i < numObjects; i++) {
	            sb.append(oList[i].toString());
	            if (i < numObjects - 1) {
	                sb.append(", ");
	            }
	        }
	        sb.append("]");
	        return sb.toString();
	    }
	
    public int size() {
        return numObjects;
    }

    // Checks if the list is empty
    public boolean isEmpty() {
        return numObjects == 0;
    }

    // Retrieves the item at the specified index
    public T get(int index) {
        if (index >= 0 && index < numObjects) {
            return (T) oList[index];
        }
        throw new IndexOutOfBoundsException("Invalid index: " + index);
    }

    // Removes the item at the specified index
    public void remove(int index) {
        if (index >= 0 && index < numObjects) {
            for (int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            oList[numObjects - 1] = null;
            numObjects--;
        } else {
            throw new IndexOutOfBoundsException("Invalid index: " + index);
        }
    }
    public void reset() {
        curr = 0;
    }

    // Get the next element in the list, if available
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more elements in the list");
        }
        return (T) oList[curr++];
    }

    // Check if there are more elements to iterate over
    public boolean hasNext() {
        return curr < numObjects;
    }

    // Remove the last element returned by the next method
    public void remove() {
        if (curr <= 0) {
            throw new IllegalStateException("next() has not been called, or remove() has already been called after the last call to next()");
        }
        remove(curr - 1); // Adjust because curr has already been incremented by next()
        curr--; // Adjust curr back after removal
    }
}
    
